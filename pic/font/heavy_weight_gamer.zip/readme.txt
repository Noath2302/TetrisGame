                                                                     __      
 _________                  __                                      /\_\           
/\  _______\               /\ \                                     \/_/             
\ \ \______/              _\_\ \____    _____    __ _____  __ ___ ___   __   __ _____ 
 \ \ \_______    X     X /\____  ___\  /'____'\ /\ V_____\/\ V   V   \ /\ \ /\ V  __ \ 
  \ \  _______\    X  X  \/___/\ \__/ /\ \__L\ \\ \ \____/\ \  /\  /\ \\ \ \\ \  /_/\ \
   \ \ \______/      X        \ \ \   \ \  ____/ \ \ \     \ \ \ \ \ \ \\ \ \\ \ \ \ \ \
    \ \ \_______    X  X       \ \ \___\ \ \___L__\ \ \     \ \ \ \ \ \ \\ \ \\ \ \ \ \ \
     \ \_________\ X     X      \ \____\\ \_______\\ \_\     \ \_\ \_\ \_\\ \_\\ \_\ \ \_\
      \/_________/               \/____/ \/_______/ \/_/      \/_/\/_/\/_/ \/_/ \/_/  \/_/ 


                       _____       __                                    
                      / ___ \     /\ \                                     
                     /\ \  \ \   _\_\ \____    ______   __ _____           
                     \ \ \__\ \ /\____  ___\  / ____ \ /\ V_____\        
                      \ >  ___< \/___/\ \__/ /\ \__/\ \\ \ \____/         
                       > \ \  \ \    \ \ \   \ \ \ \ \ \\ \ \             
                        \ \ \__\ \    \ \ \___\ \ \_\_\ \\ \ \           
                         \ \_____/     \ \____\\ \______/ \ \_\        
                          \/____/       \/____/ \/_____/   \/_/          




		+-----------------------------------------------------------+
		�   	     Heavy Weight Gamer Font  version 1 -2005       �       
		�      	     created by extermin8tor                        �              
		+-----------------------------------------------------------+
:::::::::::::!Thanks for downloading this font!:::::::::::::

I hope you enjoy using this font, please distribute it anywhere, and you may bundle it with anything eg. templates, etc. You do not have to leave any credit to me, but if you host this font on your site i would like you to leave it in the original package. This font may be modified. Thanks.

Have fun using the font!!!!!!!!!!!!!!!
;)

For more fonts, templates, webmaster resources and much more visit www.bestfreetemplates.net.
I make custom fonts as well as sites and HTML templates. Please visit my site, if you like this font. And if you dont, then go there and find something you Do like! :)
If you have any questions or comments please mail me at extermin8tor(at)gmail.coma